/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lat2;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.FlowLayout;
/**
 *
 * @author Evelyn Wijaya
 */
public class Lat2 extends JFrame {
    /**
     * @param args the command line arguments
     */
    public Lat2(){
        //membuat obyek layout manager
        FlowLayout flowLayout = new FlowLayout(FlowLayout.CENTER, 5, 10);
        
        //memperoleh kontent pane dari frame
        Container container =getContentPane();
        
        //mengatur layout manager dari content pane
        container.setLayout(flowLayout);
        
        //menambahkan lima button ke content pane 
        container.add(new JButton("Tombol 1"));
        container.add(new JButton("Tombol 2"));
        container.add(new JButton("Tombol 3"));
        container.add(new JButton("Tombol 4"));
        container.add(new JButton("Tombol 5"));
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
    Lat2 jendela = new Lat2();
    jendela.setTitle("Kelas DemoFlowLayout");
    jendela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    jendela.setSize(390, 120);
    jendela.setVisible(true);
  
    }
    
}
